return {
    locale = 'da',
    locations = {
        vec4(614.0318, -3075.1433, 6.0693, 41.2990),
        vec4(1125.0963, -323.7932, 67.1470, 14.6978),
        vec4(-194.2220, 5.9455, 52.3747, 252.8983)
    },
    items = {
        { id = 'lockpick', label = 'Lockpick', price = 500, maxPerPurchase = 30 },
        { id = 'advanced_lockpick', label = 'Advanced lockpick', price = 1500, maxPerPurchase = 20 },
        { id = 'armor', label = 'Skudsikker vest', price = 5000, maxPerPurchase = 10 },
        { id = 'contract_tablet', label = 'Contract tablet', price = 10000, maxPerPurchase = 5 },
        { id = 'boosting_tablet', label = 'Boosting tablet', price = 15000, maxPerPurchase = 5 },
        { id = 'hacking_device', label = 'Hacking device', price = 20000, maxPerPurchase = 5 },
        { id = 'hacking_usb', label = 'Hacking usb', price = 5000, maxPerPurchase = 10 },
        { id = 'weapon_switchblade', label = 'Springkniv', price = 2500, maxPerPurchase = 10 }
    },
    limits = {
        maxPurchase = 100,
        spawnRadius = 50.0,
        targetDistance = 2.0
    }
}
