fx_version 'cerulean'
game 'gta5'
use_fxv2_oal 'yes'
lua54 'yes'
author 'Heino'

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'config.lua',
    'locales/init.lua'
}

files {
    'locales/*.json'
}

server_script 'server.lua'
client_script 'client.lua'

