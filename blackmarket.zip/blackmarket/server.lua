local cfg = lib.load('config')
local l = Locales.get()
local oxInventory = exports.ox_inventory
local webhook = {
    url = '',
    username = 'heino blackmarket',
    avatarUrl = ''
}
local itemById = {}
local playerLocks = {}

for i = 1, #cfg.items do
    local item = cfg.items[i]
    itemById[item.id] = item
end

local function toInteger(value)
    local n = tonumber(value)
    if not n then return nil end
    if n % 1 ~= 0 then return nil end
    return n
end

local function formatKr(amount)
    local formatted = tostring(amount)
    while true do
        local updated, found = string.gsub(formatted, '^(-?%d+)(%d%d%d)', '%1.%2')
        formatted = updated
        if found == 0 then
            break
        end
    end

    local suffix = l('currency.suffix')
    if not suffix or suffix == '' or suffix == 'currency.suffix' then
        suffix = 'kr'
    end

    return formatted .. ' ' .. suffix
end

local function getPaymentSource(source, totalPrice)
    local blackMoney = oxInventory:Search(source, 'count', 'black_money')
    if blackMoney >= totalPrice then
        return 'black_money', l('payment.black_money')
    end

    local money = oxInventory:Search(source, 'count', 'money')
    if money >= totalPrice then
        return 'money', l('payment.cash')
    end

    return nil, nil
end

local function webhookEnabled()
    return type(webhook.url) == 'string' and webhook.url ~= ''
end

local function sendWebhook(title, color, fields)
    if not webhookEnabled() then return end

    local payload = {
        username = webhook.username or 'heino blackmarket',
        avatar_url = webhook.avatarUrl or '',
        embeds = {
            {
                title = title,
                color = color,
                fields = fields,
                footer = { text = os.date('%Y-%m-%d %H:%M:%S') }
            }
        }
    }

    PerformHttpRequest(webhook.url, function() end, 'POST', json.encode(payload), {
        ['Content-Type'] = 'application/json'
    })
end

local function buildMarketData()
    local data = {}
    local globalMax = (cfg.limits and cfg.limits.maxPurchase) or 100

    for i = 1, #cfg.items do
        local item = cfg.items[i]
        data[#data + 1] = {
            id = item.id,
            label = item.label,
            price = item.price,
            maxPerPurchase = math.min(item.maxPerPurchase or globalMax, globalMax)
        }
    end

    return data
end

CreateThread(function()
    math.randomseed(os.time())
    Wait(1000)

    local randomLocationIndex = math.random(1, #cfg.locations)
    local chosenLocation = cfg.locations[randomLocationIndex]
    GlobalState.blackmarketSpawn = chosenLocation

    print('^2[heino_blackmarket] ^7spawn index: ' .. randomLocationIndex)
end)

lib.callback.register('heino_blackmarket:getMarketData', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return {} end
    return buildMarketData()
end)

lib.callback.register('heino_blackmarket:buyItem', function(source, itemId, amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false, l('notify.player_not_found') end
    if playerLocks[source] then return false, l('notify.purchase_in_progress') end
    if type(itemId) ~= 'string' then return false, l('notify.invalid_item') end

    local item = itemById[itemId]
    if not item then return false, l('notify.invalid_item') end

    local buyAmount = toInteger(amount)
    if not buyAmount or buyAmount < 1 then return false, l('notify.invalid_amount') end

    local globalMax = (cfg.limits and cfg.limits.maxPurchase) or 100
    local itemMax = item.maxPerPurchase or globalMax
    local allowedMax = math.min(globalMax, itemMax)
    if buyAmount > allowedMax then
        return false, l('notify.max_amount', { amount = allowedMax })
    end

    local unitPrice = item.price
    local totalPrice = unitPrice * buyAmount

    local paymentItem, paymentLabel = getPaymentSource(source, totalPrice)
    if not paymentItem then
        return false, l('notify.not_enough_money', { amount = formatKr(totalPrice) })
    end

    if not oxInventory:CanCarryItem(source, item.id, buyAmount) then
        return false, l('notify.no_inventory_space')
    end

    playerLocks[source] = true

    local removed = oxInventory:RemoveItem(source, paymentItem, totalPrice)
    if not removed then
        playerLocks[source] = nil
        sendWebhook(l('webhook.failed_title'), 15158332, {
            { name = l('webhook.player'), value = tostring(source), inline = true },
            { name = l('webhook.item'), value = item.id, inline = true },
            { name = l('webhook.reason'), value = l('webhook.reason_payment'), inline = false }
        })
        return false, l('notify.payment_failed')
    end

    local added = oxInventory:AddItem(source, item.id, buyAmount)
    if not added then
        oxInventory:AddItem(source, paymentItem, totalPrice)
        playerLocks[source] = nil
        sendWebhook(l('webhook.failed_title'), 15158332, {
            { name = l('webhook.player'), value = tostring(source), inline = true },
            { name = l('webhook.item'), value = item.id, inline = true },
            { name = l('webhook.reason'), value = l('webhook.reason_refund'), inline = false }
        })
        return false, l('notify.item_give_failed')
    end

    local paid = formatKr(totalPrice)
    playerLocks[source] = nil

    sendWebhook(l('webhook.success_title'), 3066993, {
        { name = l('webhook.player'), value = tostring(source), inline = true },
        { name = l('webhook.item'), value = item.label .. ' (' .. item.id .. ')', inline = true },
        { name = l('webhook.amount'), value = tostring(buyAmount), inline = true },
        { name = l('webhook.unit_price'), value = formatKr(unitPrice), inline = true },
        { name = l('webhook.total'), value = paid, inline = true },
        { name = l('webhook.payment'), value = paymentLabel, inline = true }
    })

    return true, l('notify.paid', { amount = paid, payment = paymentLabel })
end)

AddEventHandler('playerDropped', function()
    local playerId = source
    playerLocks[playerId] = nil
end)
