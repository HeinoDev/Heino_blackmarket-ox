local cfg = lib.load('config')
local l = Locales.get()
local ped = nil
local isSpawned = false

local pedModel = 'a_m_m_og_boss_01'
local pedAnimDict = 'amb@world_human_stand_guard@male@base'
local pedAnimName = 'base'
local targetIcon = 'fas fa-user-ninja'

local function formatNumber(num)
    if not num then return '0' end
    local formatted = tostring(num)
    while true do
        formatted, k = string.gsub(formatted, '^(-?%d+)(%d%d%d)', '%1.%2')
        if k == 0 then
            break
        end
    end
    return formatted
end

local function formatKr(amount)
    local suffix = l('currency.suffix')
    if not suffix or suffix == '' or suffix == 'currency.suffix' then
        suffix = 'kr'
    end
    return formatNumber(amount) .. ' ' .. suffix
end

local function openBlackmarketMenu()
    local options = {}
    local marketItems = lib.callback.await('heino_blackmarket:getMarketData', false)

    if type(marketItems) ~= 'table' or #marketItems == 0 then
        lib.notify({ title = l('notify.error_title'), description = l('notify.shop_not_ready'), type = 'error' })
        return
    end

    for i = 1, #marketItems do
        local item = marketItems[i]

        table.insert(options, {
            title = item.label,
            description = l('menu.price', { amount = formatKr(item.price) }),
            icon = 'box',
            onSelect = function()
                local input = lib.inputDialog(l('menu.buy_title', { item = item.label }), {
                    { type = 'number', label = l('menu.amount_label'), description = l('menu.unit_price', { amount = formatKr(item.price) }), required = true, default = 1, min = 1, max = item.maxPerPurchase or 100 }
                })

                if not input then
                    openBlackmarketMenu()
                    return
                end

                local amount = tonumber(input[1])
                if not amount or amount <= 0 then
                    lib.notify({ title = l('notify.error_title'), description = l('notify.invalid_amount'), type = 'error' })
                    return openBlackmarketMenu()
                end

                local success, msg = lib.callback.await('heino_blackmarket:buyItem', false, item.id, amount)

                if success then
                    lib.notify({
                        title = l('notify.buy_success_title'),
                        description = l('notify.buy_success_desc', { amount = amount, item = item.label }) .. '\n' .. msg,
                        type = 'success'
                    })
                else
                    lib.notify({
                        title = l('notify.buy_failed_title'),
                        description = msg,
                        type = 'error'
                    })
                end

                openBlackmarketMenu()
            end
        })
    end

    lib.registerContext({
        id = 'blackmarket_menu',
        title = l('menu.title'),
        options = options
    })

    lib.showContext('blackmarket_menu')
end

local function spawnPed(coords)
    if isSpawned then return end

    lib.requestModel(pedModel)
    local pedHash = GetHashKey(pedModel)

    ped = CreatePed(0, pedHash, coords.x, coords.y, coords.z - 1.0, coords.w, false, true)

    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)
    SetPedCanPlayAmbientAnims(ped, true)
    SetPedCanRagdollFromPlayerImpact(ped, false)
    SetEntityHeading(ped, coords.w)

    lib.requestAnimDict(pedAnimDict)
    TaskPlayAnim(ped, pedAnimDict, pedAnimName, 8.0, -8.0, -1, 1, 0, false, false, false)

    exports.ox_target:addLocalEntity(ped, {
        {
            name = 'blackmarket_access',
            icon = targetIcon,
            label = l('target.label'),
            onSelect = function()
                openBlackmarketMenu()
            end,
            distance = (cfg.limits and cfg.limits.targetDistance) or 2.0
        }
    })

    isSpawned = true
end

CreateThread(function()
    while not GlobalState.blackmarketSpawn do
        Wait(500)
    end

    local locationCoords = GlobalState.blackmarketSpawn

    while true do
        local msec = 1000
        local plyCoords = GetEntityCoords(cache.ped)
        local dist = #(plyCoords - vector3(locationCoords.x, locationCoords.y, locationCoords.z))

        if dist < ((cfg.limits and cfg.limits.spawnRadius) or 50.0) then
            msec = 500
            if not isSpawned then
                spawnPed(locationCoords)
            end
        else
            if isSpawned then
                if ped and DoesEntityExist(ped) then
                    exports.ox_target:removeLocalEntity(ped, 'blackmarket_access')
                    DeletePed(ped)
                    ped = nil
                end
                isSpawned = false
            end
        end

        Wait(msec)
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        if ped and DoesEntityExist(ped) then
            exports.ox_target:removeLocalEntity(ped, 'blackmarket_access')
            DeletePed(ped)
            ped = nil
        end
    end
end)
