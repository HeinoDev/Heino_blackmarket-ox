local cfg = lib.load('config')
local resourceName = GetCurrentResourceName()
local activeLocale = (cfg and cfg.locale) or 'da'
local fallbackLocale = 'en'
local cache = {}

local function decodeLocale(locale)
    local raw = LoadResourceFile(resourceName, ('locales/%s.json'):format(locale))
    if not raw then
        return {}
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= 'table' then
        return {}
    end

    return decoded
end

local function getLocaleTable(locale)
    if cache[locale] then
        return cache[locale]
    end

    local loaded = decodeLocale(locale)
    cache[locale] = loaded
    return loaded
end

local function interpolate(input, vars)
    if type(vars) ~= 'table' then
        return input
    end

    return (input:gsub('{([%w_]+)}', function(token)
        local value = vars[token]
        if value == nil then
            return '{' .. token .. '}'
        end
        return tostring(value)
    end))
end

local function resolve(locale, key)
    local localeTable = getLocaleTable(locale)
    local fallbackTable = getLocaleTable(fallbackLocale)
    local value = localeTable[key]
    if value == nil then
        value = fallbackTable[key]
    end
    if type(value) ~= 'string' then
        return key
    end
    return value
end

Locales = {}

function Locales.t(key, vars, locale)
    local selected = locale or activeLocale
    local template = resolve(selected, key)
    return interpolate(template, vars)
end

function Locales.get(locale)
    return function(key, vars)
        return Locales.t(key, vars, locale)
    end
end

function Locales.reload(locale)
    if locale and type(locale) == 'string' and locale ~= '' then
        activeLocale = locale
    end
    cache = {}
end
